package Location;

import DateTime.Schedule;

public class Location {
    private String name;
    private Schedule schedule; //schedule of the location. a several-hour window over a span of several days a week
    private String  address;
    private String city;
    
}
