package Service;

public class Lesson {

}
